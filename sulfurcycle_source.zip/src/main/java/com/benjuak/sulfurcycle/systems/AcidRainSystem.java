package com.benjuak.sulfurcycle.systems;

import com.benjuak.sulfurcycle.world.VolcanoState;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Blocks;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Random;

public class AcidRainSystem {
    private static final int TICKS_BETWEEN = 20; // 1 segundo
    private static final Random RANDOM = new Random();

    public static void init() {
        ServerTickEvents.START_WORLD_TICK.register(world -> {
            if (world instanceof ServerWorld sw) {
                tick(sw);
            }
        });
    }

    private static void tick(ServerWorld world) {
        if (world.getServer().getTicks() % TICKS_BETWEEN != 0) return;
        if (!world.isRaining()) return;

        for (PlayerEntity player : world.getPlayers()) {
            BlockPos ppos = player.getBlockPos();
            VolcanoState vs = VolcanoState.get(world);
            boolean nearVolcano = vs.getVolcanoes().stream().anyMatch(vp -> vp.isWithinDistance(ppos, 128.0));
            if (nearVolcano) {
                applyAcidEffects(world, ppos);
            }
        }
    }

    private static void applyAcidEffects(ServerWorld world, BlockPos center) {
        for (int i = 0; i < 25; i++) {
            double rx = center.getX() + (RANDOM.nextDouble() - 0.5) * 20;
            double ry = center.getY() + RANDOM.nextDouble() * 10;
            double rz = center.getZ() + (RANDOM.nextDouble() - 0.5) * 20;
            world.spawnParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, rx, ry, rz, 1, 0.05, 0.05, 0.05, 0.0);
        }

        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                BlockPos pos = center.add(dx, 0, dz);
                BlockPos below = pos.down();
                if (world.getBlockState(below).isOf(Blocks.FARMLAND)) {
                    BlockPos crop = below.up();
                    if (world.getBlockState(crop).isOf(Blocks.WHEAT)) {
                        if (RANDOM.nextDouble() < 0.03) {
                            world.setBlockState(crop, Blocks.AIR.getDefaultState());
                        }
                    }
                }
            }
        }
    }
}
