package com.benjuak.sulfurcycle;

import com.benjuak.sulfurcycle.registry.ModBlocks;
import com.benjuak.sulfurcycle.registry.ModItems;
import com.benjuak.sulfurcycle.world.ModWorldGen;
import com.benjuak.sulfurcycle.systems.AcidRainSystem;
import net.fabricmc.api.ModInitializer;

public class SulfurCycleMod implements ModInitializer {
    public static final String MODID = "sulfurcycle";

    @Override
    public void onInitialize() {
        ModBlocks.register();
        ModItems.register();
        ModWorldGen.register();
        AcidRainSystem.init();
        System.out.println("[SulfurCycle] initialized");
    }
}
