package com.benjuak.sulfurcycle.world;

import com.benjuak.sulfurcycle.SulfurCycleMod;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;

import java.util.HashSet;
import java.util.Set;

public class VolcanoState extends PersistentState {
    private static final String KEY = SulfurCycleMod.MODID + "_volcano_state";
    private final Set<BlockPos> volcanoes = new HashSet<>();

    public static VolcanoState get(ServerWorld world) {
        PersistentState state = world.getPersistentStateManager().get(KEY);
        if (state instanceof VolcanoState vs) {
            return vs;
        } else {
            VolcanoState vsNew = new VolcanoState();
            world.getPersistentStateManager().set(KEY, vsNew);
            return vsNew;
        }
    }

    public void addVolcano(BlockPos pos) {
        volcanoes.add(pos);
    }

    public Set<BlockPos> getVolcanoes() {
        return volcanoes;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtList list = new NbtList();
        for (BlockPos p : volcanoes) {
            NbtCompound comp = new NbtCompound();
            comp.putInt("x", p.getX());
            comp.putInt("y", p.getY());
            comp.putInt("z", p.getZ());
            list.add(comp);
        }
        nbt.put("volcanoes", list);
        return nbt;
    }

    @Override
    public void readNbt(NbtCompound nbt) {
        volcanoes.clear();
        if (nbt.contains("volcanoes")) {
            NbtList list = nbt.getList("volcanoes", 10);
            list.forEach(tag -> {
                if (tag instanceof NbtCompound c) {
                    int x = c.getInt("x"), y = c.getInt("y"), z = c.getInt("z");
                    volcanoes.add(new BlockPos(x, y, z));
                }
            });
        }
    }
}
