package com.benjuak.sulfurcycle.world;

public class ModWorldGen {
    public static void register() {
        // Placeholder: implement ConfiguredFeature and PlacedFeature for sulfur_ore generation if needed.
    }
}
