package com.benjuak.sulfurcycle.client;

import net.fabricmc.api.ClientModInitializer;

public class ClientInit implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // place for particle factories if needed
    }
}
