package com.benjuak.sulfurcycle.block;

import com.benjuak.sulfurcycle.world.VolcanoState;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.entity.player.PlayerEntity;

public class VolcanoBlock extends Block {
    public VolcanoBlock(Settings settings) {
        super(settings);
    }

    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, PlayerEntity placer, net.minecraft.item.ItemStack itemStack) {
        super.onPlaced(world, pos, state, placer, itemStack);
        if (!world.isClient()) {
            if (world instanceof ServerWorld sw) {
                VolcanoState stateData = VolcanoState.get(sw);
                stateData.addVolcano(pos);
                stateData.markDirty();
            }
        }
    }

    @Override
    public void onSteppedOn(World world, BlockPos pos, BlockState state, LivingEntity entity) {
        super.onSteppedOn(world, pos, state, entity);
        if (!world.isClient()) {
            entity.setOnFireFor(4); // si el jugador pisa, se prende fuego (comportamiento físico)
        }
    }
}
