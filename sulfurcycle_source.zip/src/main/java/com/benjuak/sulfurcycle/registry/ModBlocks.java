package com.benjuak.sulfurcycle.registry;

import com.benjuak.sulfurcycle.SulfurCycleMod;
import com.benjuak.sulfurcycle.block.VolcanoBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModBlocks {
    public static final Block SULFUR_ORE = new Block(Block.Settings.of(Material.STONE).strength(3.0f));
    public static final Block VOLCANO_BLOCK = new VolcanoBlock(Block.Settings.of(Material.STONE).strength(5.0f));

    public static void register() {
        Registry.register(Registries.BLOCK, new Identifier(SulfurCycleMod.MODID, "sulfur_ore"), SULFUR_ORE);
        Registry.register(Registries.BLOCK, new Identifier(SulfurCycleMod.MODID, "volcano_block"), VOLCANO_BLOCK);

        Registry.register(Registries.ITEM, new Identifier(SulfurCycleMod.MODID, "sulfur_ore"),
                new BlockItem(SULFUR_ORE, new Item.Settings().group(ItemGroup.BUILDING_BLOCKS)));
        Registry.register(Registries.ITEM, new Identifier(SulfurCycleMod.MODID, "volcano_block"),
                new BlockItem(VOLCANO_BLOCK, new Item.Settings().group(ItemGroup.DECORATIONS)));
    }
}
