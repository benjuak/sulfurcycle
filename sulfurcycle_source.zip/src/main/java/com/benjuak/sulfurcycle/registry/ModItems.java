package com.benjuak.sulfurcycle.registry;

import com.benjuak.sulfurcycle.SulfurCycleMod;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
    public static final Item RAW_SULFUR = new Item(new Item.Settings().group(ItemGroup.MATERIALS));
    public static final Item REFINED_SULFUR = new Item(new Item.Settings().group(ItemGroup.MATERIALS));

    public static void register() {
        Registry.register(Registries.ITEM, new Identifier(SulfurCycleMod.MODID, "raw_sulfur"), RAW_SULFUR);
        Registry.register(Registries.ITEM, new Identifier(SulfurCycleMod.MODID, "refined_sulfur"), REFINED_SULFUR);
    }
}
